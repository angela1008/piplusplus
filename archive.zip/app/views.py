from django.shortcuts import render
from django.shortcuts import render_to_response
from django.contrib.auth.models import User
from django.contrib.sessions.models import Session
from django.db.models import Q
from django.core.exceptions import ObjectDoesNotExist
from django.http import HttpResponse

from api import models

# Create your views here.
def index(request):
    return render_to_response('index.html', locals())


def use_session(request):
    request.session['lucky_number'] = 8

    if 'lucky_number' in request.session:
        lucky_number = request.session['lucky_number']

        response = HttpResponse('Your lucky_number is '+lucky_number)
    del request.session['lucky_number']

    return response
    
def session_test(request):
    sid = request.COOKIES['sessionid']
    s = Session.objects.get(pk=sid)
    s_info = 'Session ID:' + sid + '<br>Expire_date:' + str(s.expire_date) + '<br>Data:' + str(s.get_decoded())
    return HttpResponse(s_info)
    
